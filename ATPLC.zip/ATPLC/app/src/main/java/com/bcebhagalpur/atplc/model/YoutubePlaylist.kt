package com.bcebhagalpur.atplc.model

data class YoutubePlaylist(
    val title:String,
    val description:String,
    val url:String,
    val videoId:String,
    val position:String
)