package com.bcebhagalpur.atplc.model

class ChatQna {
    val  id: String?=null
    val message:String?=null
    val fullName:String?=null
}