package com.bcebhagalpur.atplc.model

class Students {
    val  branch: String?=null
    val college:String?=null
    val email:String?=null
    val fullName:String?=null
    val iPath:String?=null
    val image:String?=null
    val mobileNumber:String?=null
    val userId:String?=null
}
